#include <stdio.h>

int main() {
    int i = 13;
    printf( "Hello world!" );
    return 0;
}
